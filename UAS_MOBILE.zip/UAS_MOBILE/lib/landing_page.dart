import 'package:UAS_MOBILE/abon.dart';
import 'package:UAS_MOBILE/brownies.dart';
import 'package:UAS_MOBILE/burger.dart';
import 'package:UAS_MOBILE/form.dart';
import 'package:UAS_MOBILE/mcoklat.dart';
import 'package:UAS_MOBILE/sandwich.dart';
import 'package:UAS_MOBILE/tiramisu.dart';
import 'package:flutter/material.dart';



class LandingPage extends StatelessWidget {
  const LandingPage({Key? key, required this.title}) : super(key: key);

  final String title;

  Widget containerAtas(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;

    return Container(
      child: Column(
        children: [
          Container(
            width: lebar,
            height: 300,
            decoration: const BoxDecoration(
              color: Color(0xFFFFCA28),
              image: DecorationImage(
                image: AssetImage("assets/welcome.png"),
              ),
            ),
            child: Column(
              children: [
                TextField(
                  style: const TextStyle(color: Colors.white),
                  cursorColor: Colors.white,
                  decoration: InputDecoration(
                    hintText: "Search",
                    hintStyle: const TextStyle(color: Colors.white),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(50.0),
                      borderSide: BorderSide.none
                      ),
                      prefixIcon: const Icon(
                        Icons.search,
                        color: Colors.white,
                        ),
                        filled: true,
                        fillColor: Colors.white24,
                  ),
                ),
              ],
            ),
          )
        ],
      ),   
    );
  }

  Widget rowContainer1() {
    return Container(
      width: 60,
      height: 80,
      margin: const EdgeInsets.all(10.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10.0),
        color: Colors.white,
        image: const DecorationImage(
          image: AssetImage("assets/bread.jpg"),
        ),
      ),
      child: Container(
        margin: const EdgeInsets.fromLTRB(20, 70, 0, 0),
        child: Row(
          children: const [
            Text(
              "Roti",
              style: TextStyle(
                color: Colors.black,
                fontSize: 10,
                fontWeight: FontWeight.bold,
              )
            ),
          ]
        )
      ),
    );
  }

  Widget rowContainer2() {
    return Container(
      width: 60,
      height: 80,
      margin: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10.0),
        color: Colors.white,
        image: const DecorationImage(
          image: AssetImage("assets/desert1.jpg"),
        ),
      ),
      child: Container(
        margin: const EdgeInsets.fromLTRB(12, 70, 0, 0),
        child: Row(
          children: const [
            Text(
              "Dessert",
              style: TextStyle(
                color: Colors.black,
                fontSize: 10,
                fontWeight: FontWeight.bold,
              )
            ),
          ]
        )
      ),
    );
  }

  Widget rowContainer3() {
    return Container(
      width: 60,
      height: 80,
      margin: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10.0),
        color: Colors.white,
        image: const DecorationImage(
          image: AssetImage("assets/fastfood1.jpg"),
        ),
      ),
      child: Container(
        margin: const EdgeInsets.fromLTRB(8, 70, 0, 0),
        child: Row(
          children: const [
            Text(
              "Fast Food",
              style: TextStyle(
                color: Colors.black,
                fontSize: 10,
                fontWeight: FontWeight.bold,
              )
            ),
          ]
        )
      ),
    );
  }

  Widget rowContainer4() {
    return Container(
      width: 60,
      height: 80,
      margin: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10.0),
        color: Colors.white,
        image: const DecorationImage(
          image: AssetImage("assets/drinkss.jpg"),
        ),
      ),
      child: Container(
        margin: const EdgeInsets.fromLTRB(15, 70, 0, 0),
        child: Row(
          children: const [
            Text(
              "Drinks",
              style: TextStyle(
                color: Colors.black,
                fontSize: 10,
                fontWeight: FontWeight.bold,
              )
            ),
          ]
        )
      ),
    );
  }

  Widget columnContainer1(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(10),
      elevation: 0,
        shape: RoundedRectangleBorder(
          side: BorderSide(
            color: Theme.of(context).colorScheme.outline,
          ),
          borderRadius: const BorderRadius.all(Radius.circular(12)),
        ),
      child: SizedBox(
        width: 400,
        height: 150,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Padding(padding: EdgeInsets.fromLTRB(20, 0, 0, 0)),
            Image.asset(
              "assets/brownies.jpg",
              width: 100,
              height: 180,
            ),
            RichText(
              text: const TextSpan(
                style: TextStyle(
                  color: Colors.black,
                ),
                children: <TextSpan>[
                  TextSpan(
                    text: " Brownies \n",
                    style: TextStyle(
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold,
                    )
                  ),
                  TextSpan(
                    text: " Rp 25.000 ",
                    style: TextStyle(
                      fontSize: 15.0,
                    )
                  )
                ]
              )
            ),
            
            Container(
              margin: const EdgeInsets.fromLTRB(60, 80, 0, 0),
              width: 60,
              height: 48,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(13),
                color: Colors.black12,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => const BrowniesPage()));
                    }, 
                    icon: Icon(Icons.shopping_cart_outlined)
                    ), 
                ],
              )
            ),
          ],
        ),
      ),
    );
  }

  Widget columnContainer2(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(10),
      elevation: 0,
      shape: RoundedRectangleBorder(
        side: BorderSide(
          color: Theme.of(context).colorScheme.outline,
        ),
        borderRadius: const BorderRadius.all(Radius.circular(12)),
      ),
      child: SizedBox(
        width: 400,
        height: 150,      
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Padding(padding: EdgeInsets.fromLTRB(20, 0, 0, 0)),
            Image.asset(
              "assets/rotiabon.jpg",
              width: 100,
              height: 150,
            ),
            RichText(
              text: const TextSpan(
                style: TextStyle(
                  color: Colors.black,
                ),
                children: <TextSpan>[
                  TextSpan(
                    text: " Roti Abon \n",
                    style: TextStyle(
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold,
                    )
                  ),
                  TextSpan(
                    text: " Rp 18.000 ",
                    style: TextStyle(
                      fontSize: 15.0,
                    )
                  )
                ]
              )
            ),
            
            Container(
              margin: const EdgeInsets.fromLTRB(55, 80, 0, 0),
              width: 60,
              height: 48,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(13),
                color: Colors.black12,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => const AbonPage()));
                    }, 
                    icon: Icon(Icons.shopping_cart_outlined)
                    ), 
                ], 
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget columnContainer3(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(10),
      elevation: 0,
      shape: RoundedRectangleBorder(
        side: BorderSide(
          color: Theme.of(context).colorScheme.outline,
        ),
        borderRadius: const BorderRadius.all(Radius.circular(12)),
      ),
      child: SizedBox(
        width: 400,
        height: 150,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Padding(padding: EdgeInsets.fromLTRB(20, 0, 0, 0)),
            Image.asset(
              "assets/tiramisucake.jpg",
              width: 100,
              height: 120,
            ),
            RichText(
              text: const TextSpan(
                style: TextStyle(
                  color: Colors.black,
                ),
                children: <TextSpan>[
                  TextSpan(
                    text: " Tiramisu Cake \n",
                    style: TextStyle(
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold,
                    )
                  ),
                  TextSpan(
                    text: " Rp 25.000 ",
                    style: TextStyle(
                      fontSize: 15.0,
                    )
                  )
                ]
              )
            ),
            
            Container(
              margin: const EdgeInsets.fromLTRB(15, 80, 0, 0),
              width: 60,
              height: 48,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(13),
                color: Colors.black12,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => const TiramisuPage()));
                    }, 
                    icon: Icon(Icons.shopping_cart_outlined)
                    ), 
                ], 
              ),
            )
          ]
        ),
      ),
    );
  }

  Widget columnContainer4(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(10),
      elevation: 0,
      shape: RoundedRectangleBorder(
        side: BorderSide(
          color: Theme.of(context).colorScheme.outline,
        ),
        borderRadius: const BorderRadius.all(Radius.circular(12)),
      ),
      child: SizedBox(
        width: 400,
        height: 150,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Padding(padding: EdgeInsets.fromLTRB(20, 0, 0, 0)),
            Image.asset(
              "assets/sandwich.jpg",
              width: 100,
              height: 120,
            ),
            RichText(
              text: const TextSpan(
                style: TextStyle(
                  color: Colors.black,
                ),
                children: <TextSpan>[
                  TextSpan(
                    text: " Sandwich \n",
                    style: TextStyle(
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold,
                    )
                  ),
                  TextSpan(
                    text: " Rp 32.000 ",
                    style: TextStyle(
                      fontSize: 15.0,
                    )
                  )
                ]
              )
            ),
            
            Container(
              margin: const EdgeInsets.fromLTRB(57, 80, 0, 0),
              width: 60,
              height: 48,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(13),
                color: Colors.black12,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => const SandwichPage()));
                    }, 
                    icon: Icon(Icons.shopping_cart_outlined)
                    ), 
                ], 
              ),
            )
          ]
        ),
      ),
    );
  }

  Widget columnContainer5(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(10),
      elevation: 0,
      shape: RoundedRectangleBorder(
        side: BorderSide(
          color: Theme.of(context).colorScheme.outline,
        ),
        borderRadius: const BorderRadius.all(Radius.circular(12)),
      ),
      child: SizedBox(
        width: 400,
        height: 150,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Padding(padding: EdgeInsets.fromLTRB(20, 0, 0, 0)),
            Image.asset(
              "assets/burger.jpg",
              width: 100,
              height: 120,
            ),
            RichText(
              text: const TextSpan(
                style: TextStyle(
                  color: Colors.black,
                ),
                children: <TextSpan>[
                  TextSpan(
                    text: " Burger \n",
                    style: TextStyle(
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold,
                    )
                  ),
                  TextSpan(
                    text: " Rp 20.000 ",
                    style: TextStyle(
                      fontSize: 15.0,
                    )
                  )
                ]
              )
            ),
            
            Container(
              margin: const EdgeInsets.fromLTRB(80, 80, 0, 0),
              width: 60,
              height: 48,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(13),
                color: Colors.black12,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => const BurgerPage()));
                    }, 
                    icon: Icon(Icons.shopping_cart_outlined)
                    ), 
                ], 
              ),
            )
          ]
        ),
      ),
    );
  }

  Widget columnContainer6(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(10),
      elevation: 0,
      shape: RoundedRectangleBorder(
        side: BorderSide(
          color: Theme.of(context).colorScheme.outline,
        ),
        borderRadius: const BorderRadius.all(Radius.circular(12)),
      ),
      child: SizedBox(
        width: 400,
        height: 150,      
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Padding(padding: EdgeInsets.fromLTRB(10, 0, 0, 0)),
            Image.asset(
              "assets/milkshakecoklat.jpg",
              width: 100,
              height: 120,
            ),
            RichText(
              text: const TextSpan(
                style: TextStyle(
                  color: Colors.black,
                ),
                children: <TextSpan>[
                  TextSpan(
                    text: " Milkshake Coklat \n",
                    style: TextStyle(
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold,
                    )
                  ),
                  TextSpan(
                    text: " Rp 18.000 ",
                    style: TextStyle(
                      fontSize: 15.0,
                    )
                  )
                ]
              )
            ),
            
            Container(
              margin: const EdgeInsets.fromLTRB(0, 80, 0, 0),
              width: 60,
              height: 48,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(13),
                color: Colors.black12,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => const McoklatPage()));
                    }, 
                    icon: Icon(Icons.shopping_cart_outlined)
                    ), 
                ], 
              ),
            )
          ]
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/drawer.png"),
                ),
              ), child: null,
            ),
            ListTile(
              title: const Text("Main Page"),
              leading: const Icon(Icons.holiday_village),
              onTap: () {
                Navigator.pushNamed(context, '/dua');
              },
            ),
            ListTile(
              title: const Text("Landing Page"),
              leading: const Icon(Icons.home),
              onTap: () {
                Navigator.pushNamed(context, '/satu');
              },
            ),
            ListTile(
              title: const Text("Profile"),
              leading: const Icon(Icons.person),
              onTap: () {
                Navigator.pushNamed(context, '/tiga');
              },
            ),
          ],
        ),
      ),
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.amber[400],
        elevation: 0,
        title: const Text(
          "Nanda Sheptiana",
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        actions: [
          IconButton(
            onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context) => MyProfile()));
            }, 
            icon: const Icon(Icons.person),
            color: Colors.white,
          ),
        ],
        centerTitle: true,
      ),

      body: ListView(
        children: [
          containerAtas(context),
          Container(
            color: Colors.yellow,
            child: Column(
              children: [
                Text(
                  "Categories",
                  style: TextStyle(
                    fontSize: 20.0,
                    color: Colors.amber[900],
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Column(
                  children: [
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(        
                        children: [
                          rowContainer1(),
                          rowContainer2(),
                          rowContainer3(),
                          rowContainer4(),
                        ],
                      )
                    ),
                    Text(
                      "Menu",
                      style: TextStyle(
                        fontSize: 20.0,
                        color: Colors.amber[900],
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    columnContainer1(context),
                    columnContainer2(context),
                    columnContainer3(context),
                    columnContainer4(context),
                    columnContainer5(context),
                    columnContainer6(context),
                    
                    Text(
                      "Lainnya",
                      style: TextStyle(
                        fontSize: 20.0,
                        color: Colors.amber[900],
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          )
          
        ],
      ),
    );
  }
}