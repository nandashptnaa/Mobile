import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:UAS_MOBILE/item_card.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: '/tiga',
      routes: {
        '/tiga': (context) => MyProfile(),
      },
      title: 'Flutter Demo',
      home: MyProfile(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyProfile extends StatelessWidget {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController ageController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController alamatController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    FirebaseFirestore firestore = FirebaseFirestore.instance;
    CollectionReference users = firestore.collection("users");

    return Scaffold(
        appBar: AppBar(
          // ignore: deprecated_member_use
          brightness: Brightness.light,
          backgroundColor: Colors.yellow,
          title: Text(
            "Profile",
            style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Colors.orange[900]
            ),
          ),
        ),
        body: Stack(
          children: [
            ListView(
              children: [
                // VIEW DATA HERE
                StreamBuilder<QuerySnapshot>(
                  stream: users.snapshots(),
                  builder: (_, snapshot) {
                    return (snapshot.hasData)
                        ? Column(
                            children: snapshot.data!.docs
                                .map(
                                  (e) => ItemCard(
                                    e.get('name'), 
                                    e.get('age'),
                                    e.get('email'), 
                                    e.get('alamat'),
                                    onDelete: (){
                                      users.doc(e.id).delete();
                                    },
                                    onUpdate1: (){
                                      users.doc(e.id).update(
                                        {'age': e.get('age') +1,
                                      });
                                    },
                                    onUpdate2: (){
                                      users.doc(e.id).update(
                                        {'age': e.get('age') -1,
                                      });
                                    },
                                  ),
                                )
                                .toList(),
                          )
                        : Text('Loading...');
                  },
                ),
                SizedBox(height: 150)
              ],
            ),
            Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  decoration: BoxDecoration(color: Colors.white, boxShadow: [
                    BoxShadow(
                        color: Colors.black12,
                        offset: Offset(-5, 0),
                        blurRadius: 15,
                        spreadRadius: 3)
                  ]),
                  width: double.infinity,
                  height: 200,
                  child: Row(
                    children: [
                      SizedBox(
                        width: MediaQuery.of(context).size.width - 160,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            TextField(
                              controller: nameController,
                              decoration: InputDecoration(hintText: "Name"),
                            ),
                            TextField(
                              controller: ageController,
                              decoration: InputDecoration(hintText: "Age"),
                              keyboardType: TextInputType.number,
                            ),
                            TextField(
                              controller: emailController,
                              decoration: InputDecoration(hintText: "Email"),
                            ),
                            TextField(
                              controller: alamatController,
                              decoration: InputDecoration(hintText: "Alamat"),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        height: 100,
                        width: 120,
                        padding: const EdgeInsets.fromLTRB(15, 15, 0, 15),
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          child: Text(
                            'Add Profile',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          onPressed: () {
                            // ADD DATA HERE
                            users.add({
                              'name': nameController.text,
                              'age': int.tryParse(ageController.text) ?? -1,
                              'email': emailController.text,
                              'alamat': alamatController.text,
                            });

                            nameController.text = '';
                            ageController.text = '';
                            emailController.text = '';
                            alamatController.text = '';

                            final snackBar = SnackBar(
                              content: Text(
                                "PROFIL BERHASIL DIBUAT !!",
                                style: TextStyle(
                                  color: Colors.black,
                                ),
                                ),
                              duration: Duration(seconds: 3),
                              padding: EdgeInsets.all(10),
                              backgroundColor: Colors.yellowAccent,
                            );
                            ScaffoldMessenger.of(context).showSnackBar(snackBar);
                          }
                        ),
                      )
                    ],
                  ),
                )
              ),
          ],
        )
    );
  }
}
