import 'package:flutter/material.dart';
import 'form.dart';
import 'landing_page.dart';
import 'searching.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: '/dua',
      routes: {
        '/dua': (context) => const MainPage(),
      },
      title: 'Flutter Demo',
      home: const MainPage(),
    );
  }
}

class MainPage extends StatefulWidget {
  const MainPage({Key? key}) : super(key: key);

  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/drawer.png"),
                ),
              ), child: null,
            ),
            ListTile(
              title: const Text("Main Page"),
              leading: const Icon(Icons.home),
              onTap: () {
                Navigator.pushNamed(context, '/dua');
              },
            ),
            ListTile(
              title: const Text("Profile"),
              leading: const Icon(Icons.home),
              onTap: () {
                Navigator.pushNamed(context, '/tiga');
              },
            ),
          ],
        ),
      ),
      appBar: AppBar(
        title: const Text("Main Page"),
      ),
    );
  }
  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int _index = 0;

  static final List<Widget> _pages = [
    const LandingPage(title: "Landing Page"),
    MyProfile(),
    const SearchPage()
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: const Text("Main Page"),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: (int index) {
          setState(() {
            _index = index;
          });
        },
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_outlined), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.circle_outlined), label: "Profile"),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: "Search"),
        ]),
      body: _pages.elementAt(_index),
    );
  }
}