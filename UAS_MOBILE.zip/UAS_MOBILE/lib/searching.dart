import 'package:flutter/material.dart';

void main() {
  runApp(const SearchPage());
}

class SearchPage extends StatefulWidget {
  const SearchPage({Key? key}) : super(key: key);

  @override
  _SearchPageState createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
//untuk searching
  bool searchIng = true;
  String query = "";
  TextEditingController cari = TextEditingController();
  List<String> dataFilter = [];

  List<String> listData = [
    "Burger",
    "Kentang",
    "Tiramisu Cake",
    "Chocolate cake",
    "Brownies",
    "Sandwich",
    "Donat",
    "Pancake",
    "Milkshake Coklat",
    "Ice Coffee",
  ];

  //search
  _SearchListViewState() {
    cari.addListener(() {
      if (cari.text.isEmpty) {
        setState(() {
          searchIng = true;
          query = "";
        });
      } else {
        setState(() {
          searchIng = false;
          query = cari.text;
        });
      }
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.amber,
        title: const Text("Search"),
      ),
      body: Column(
        children: [
          searchView(),
          searchIng ? listDataView() : performFilter(), // tambah search di is cari
        ],
      ),
    );
  }

  Widget searchView() {
    return Container(
      margin: const EdgeInsets.only(top: 10, right: 10, left: 10),
      child: TextFormField(
        controller: cari,
        decoration: InputDecoration(
            hintText: "Search",
            // prefix: Icon(Icons.search),
            hintStyle: const TextStyle(
              color: Colors.black,
            ),
            border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(10))),
      ),
    );
  }

  Widget listDataView() {
    return Flexible(
        child: ListView.builder(
            itemCount: listData.length,
            itemBuilder: (context, index) {
              return ListTile(
                title: Text('${listData[index]}'),
              );
            }));
  }

// search
  Widget performFilter() {
    //untuk search
    dataFilter = [];
    for (int i = 0; i < listData.length; i++) {
      var item = listData[i];
      if (item.toLowerCase().contains(query.toLowerCase())) {
        dataFilter.add(item);
      }
    }
    return showDataFilter();
  }

// search
  Widget showDataFilter() {
    return Flexible(
        child: ListView.builder(
            itemCount: dataFilter.length,
            itemBuilder: (context, index) {
              return ListTile(
                title: Text('${dataFilter[index]}'),
              );
            }));
  }
}