import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:UAS_MOBILE/form.dart';
import 'package:UAS_MOBILE/landing_page.dart';
import 'package:UAS_MOBILE/main_page.dart';
import 'package:UAS_MOBILE/splashscreen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: '/satu',
      routes: {
        '/satu': (context) => const LandingPage(title: 'Landing Page'),
        '/dua': (context) => const MainPage(),
        '/tiga': (context) => MyProfile()
      },
      home: const SplashScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}
