import 'dart:async';

import 'package:flutter/material.dart';
import 'package:UAS_MOBILE/landing_page.dart';


class SplashScreen extends StatefulWidget {
  const SplashScreen({ Key? key }) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    start();
  }

  start(){
    var duration = const Duration(seconds: 3);
    return Timer(
      duration,
      (){
        Navigator.pushReplacement(
          context, 
          MaterialPageRoute(builder: (context) => const LandingPage(title: 'Landing Page',)
          ),
        );
      }
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Image.asset(
          'assets/w.png',
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          
          ),
      ),
    );
  }
}